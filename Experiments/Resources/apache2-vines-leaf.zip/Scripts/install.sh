#!/usr/bin/env bash
apt-get -y install apache2